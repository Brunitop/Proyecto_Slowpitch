---
title: Markdown page example
---

# Markdown page example

You don't need React to write simple standalone pages.
