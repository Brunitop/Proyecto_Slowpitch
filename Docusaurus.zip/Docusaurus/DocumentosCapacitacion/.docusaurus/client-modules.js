export default [
  require("C:\\Users\\bruno\\Documents\\Docusaurus\\DocumentosCapacitacion\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\bruno\\Documents\\Docusaurus\\DocumentosCapacitacion\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\bruno\\Documents\\Docusaurus\\DocumentosCapacitacion\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\bruno\\Documents\\Docusaurus\\DocumentosCapacitacion\\src\\css\\custom.css"),
];
